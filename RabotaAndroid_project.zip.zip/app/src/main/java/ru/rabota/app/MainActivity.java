package ru.rabota.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int PINK=Color.rgb(255,91,173), BG=Color.rgb(20,7,17), DARK=Color.rgb(255,235,246), PALE=Color.rgb(68,24,51), CARD=Color.rgb(39,15,32), MUTED=Color.rgb(194,157,180);
    final String[] days={"Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"};
    LinearLayout root, content, nav; TextView weeklyTotalView; int weekOffset=0; String page="График";
    Calendar monday; SharedPreferences prefs;
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); getWindow().getDecorView().setSystemUiVisibility(0); prefs=getSharedPreferences("work",0); render();}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(color==CARD){d.setStroke(1,Color.rgb(91,35,68));}return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a){v.setPadding(a,a,a,a);}
    TextView button(String s,Runnable r){TextView t=text(s,15,PINK,true);t.setGravity(Gravity.CENTER);t.setPadding(14,12,14,12);t.setBackground(shape(CARD,28));t.setOnClickListener(v->r.run());return t;}
    String key(int day,String field){return dateKey(day)+"_"+field;}
    String dateKey(int day){Calendar c=(Calendar)monday.clone();c.add(Calendar.DAY_OF_MONTH,day);return new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(c.getTime());}
    Calendar weekStart(){Calendar c=Calendar.getInstance();c.setFirstDayOfWeek(Calendar.MONDAY);c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);c.add(Calendar.WEEK_OF_YEAR,weekOffset);return c;}
    void render(){
        monday=weekStart(); root=vertical();root.setBackgroundColor(BG);root.setPadding(18,14,18,10);
        TextView title=text("Работа",29,DARK,true);root.addView(title);
        TextView subtitle=text(new SimpleDateFormat("d MMM",new Locale("ru")).format(monday.getTime())+" — "+weekEnd(),14,MUTED,false);subtitle.setPadding(0,2,0,12);root.addView(subtitle);
        content=vertical(); ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=horizontal();nav.setPadding(0,8,0,0);nav.setBackground(shape(CARD,24));root.addView(nav);
        nav.addView(button("График",()->{page="График";render();}),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button("ЗП",()->{page="ЗП";render();}),new LinearLayout.LayoutParams(0,-2,1));
        setContentView(root);
        if(page.equals("График")) showSchedule();else showSalary();
    }
    String weekEnd(){Calendar c=(Calendar)monday.clone();c.add(Calendar.DAY_OF_MONTH,6);return new SimpleDateFormat("d MMM",new Locale("ru")).format(c.getTime());}
    void showSchedule(){
        LinearLayout switcher=horizontal();switcher.setGravity(Gravity.CENTER);switcher.addView(button("‹",()->{weekOffset--;render();}));TextView w=text(weekOffset==0?"Эта неделя":weekOffset<0?Math.abs(weekOffset)+" нед. назад":weekOffset+" нед. вперёд",15,DARK,true);w.setGravity(Gravity.CENTER);switcher.addView(w,new LinearLayout.LayoutParams(0,-2,1));switcher.addView(button("›",()->{weekOffset++;render();}));content.addView(switcher);
        for(int i=0;i<7;i++) dayCard(i);
        weeklyTotalView=text("Итого за неделю: "+money(weekTotal()),19,PINK,true);weeklyTotalView.setPadding(4,16,4,22);content.addView(weeklyTotalView);
    }
    void dayCard(int i){
        LinearLayout card=vertical();card.setPadding(14,12,14,12);card.setBackground(shape(CARD,22));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,6,0,6);content.addView(card,cp);
        Calendar c=(Calendar)monday.clone();c.add(Calendar.DAY_OF_MONTH,i);
        LinearLayout top=horizontal();CheckBox check=new CheckBox(this);check.setButtonTintList(android.content.res.ColorStateList.valueOf(PINK));check.setText(days[i]);check.setTextColor(DARK);check.setTextSize(16);check.setTypeface(null,Typeface.BOLD);check.setChecked(prefs.getBoolean(key(i,"on"),false));top.addView(check,new LinearLayout.LayoutParams(0,-2,1));top.addView(text(new SimpleDateFormat("d.MM",Locale.getDefault()).format(c.getTime()),13,MUTED,false));card.addView(top);
        LinearLayout fields=vertical();card.addView(fields);String date=dateKey(i);
        Spinner place=new Spinner(this);ArrayAdapter<String> ad=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,new String[]{"Овраг","Самолет"});place.setAdapter(ad);place.setSelection(prefs.getInt(date+"_place",0));fieldRow(fields,"Место",place);
        Spinner start=times(date+"_start","09:00"),end=times(date+"_end","17:00");
        fieldRow(fields,"Начало",start);fieldRow(fields,"Конец",end);
        TextView calc=text("",14,PINK,true);calc.setPadding(0,8,0,0);fields.addView(calc);
        Runnable update=()->{
            boolean on=check.isChecked();prefs.edit().putBoolean(date+"_on",on).putInt(date+"_place",place.getSelectedItemPosition()).putString(date+"_start",start.getSelectedItem().toString()).putString(date+"_end",end.getSelectedItem().toString()).apply();
            int mins=duration(start.getSelectedItem().toString(),end.getSelectedItem().toString());double hours=mins/60.0;calc.setText(on?"За день: "+fmt(hours)+" ч · "+money((long)Math.round(hours*250)):"");fields.setVisibility(on?View.VISIBLE:View.GONE);if(weeklyTotalView!=null)weeklyTotalView.setText("Итого за неделю: "+money(weekTotal()));
        };
        check.setOnCheckedChangeListener((b,v)->update.run());place.setOnItemSelectedListener(listener(update));start.setOnItemSelectedListener(listener(update));end.setOnItemSelectedListener(listener(update));
        fields.setVisibility(check.isChecked()?View.VISIBLE:View.GONE);
        int mins=duration(start.getSelectedItem().toString(),end.getSelectedItem().toString());calc.setText(check.isChecked()?"За день: "+fmt(mins/60.0)+" ч · "+money((long)Math.round(mins/60.0*250)):"");
    }
    void fieldRow(LinearLayout parent,String label,View input){LinearLayout row=horizontal();row.setPadding(0,2,0,2);row.addView(text(label,14,MUTED,false),new LinearLayout.LayoutParams(88,-2));row.addView(input,new LinearLayout.LayoutParams(0,44,1));parent.addView(row);}
    Spinner times(String k,String def){Spinner s=new Spinner(this);String[] vals=new String[48];for(int i=0;i<48;i++)vals[i]=String.format(Locale.US,"%02d:%02d",i/2,(i%2)*30);ArrayAdapter<String>a=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,vals);s.setAdapter(a);String saved=prefs.getString(k,def);for(int i=0;i<vals.length;i++)if(vals[i].equals(saved)){s.setSelection(i);break;}return s;}
    android.widget.AdapterView.OnItemSelectedListener listener(Runnable r){return new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){r.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}};}
    int duration(String a,String b){String[] x=a.split(":"),y=b.split(":");int s=Integer.parseInt(x[0])*60+Integer.parseInt(x[1]),e=Integer.parseInt(y[0])*60+Integer.parseInt(y[1]);return Math.max(0,e-s);}
    String fmt(double x){return x==(long)x?""+(long)x:String.format(Locale.US,"%.1f",x);}
    String money(long x){return x+" ₽";}
    long weekTotal(){long total=0;for(int i=0;i<7;i++)if(prefs.getBoolean(key(i,"on"),false)){String a=prefs.getString(key(i,"start"),"09:00"),b=prefs.getString(key(i,"end"),"17:00");total+=Math.round(duration(a,b)/60.0*250);}return total;}
    void showSalary(){
        TextView heading=text("Расчёт зарплаты",22,DARK,true);heading.setPadding(2,12,0,16);content.addView(heading);
        LinearLayout card=vertical();card.setPadding(18,18,18,18);card.setBackground(shape(CARD,24));content.addView(card);
        card.addView(text("Количество рабочих дней",15,DARK,true));
        EditText count=new EditText(this);count.setInputType(2);count.setSingleLine(true);count.setText("5");count.setTextSize(18);count.setTextColor(DARK);count.setHintTextColor(MUTED);count.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PINK));card.addView(count);
        TextView note=text("Считает по отмеченным сменам в сохранённом графике.",13,MUTED,false);note.setPadding(0,8,0,14);card.addView(note);
        TextView result=text("",24,PINK,true);card.addView(result);
        TextView hours=text("",15,DARK,false);hours.setPadding(0,8,0,0);card.addView(hours);
        Runnable calc=()->{int n=5;try{n=Math.max(0,Integer.parseInt(count.getText().toString()));}catch(Exception e){}ArrayList<Long> vals=new ArrayList<>();for(int i=0;i<7;i++)if(prefs.getBoolean(key(i,"on"),false)){String a=prefs.getString(key(i,"start"),"09:00"),b=prefs.getString(key(i,"end"),"17:00");vals.add((long)duration(a,b));}long mins=0;for(int i=0;i<Math.min(n,vals.size());i++)mins+=vals.get(i);result.setText(money(Math.round(mins/60.0*250)));hours.setText("Учтено смен: "+Math.min(n,vals.size())+" · Часов: "+fmt(mins/60.0));};
        count.addTextChangedListener(new android.text.TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){calc.run();}public void afterTextChanged(android.text.Editable e){}});calc.run();
        TextView hint=text("Сначала отметь смены в графике нужной недели.",13,MUTED,false);hint.setPadding(2,14,2,0);content.addView(hint);
    }
}
