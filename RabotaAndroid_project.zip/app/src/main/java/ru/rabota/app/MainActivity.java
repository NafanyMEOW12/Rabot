package ru.rabota.app;

import android.app.*;
import android.os.Bundle;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.provider.MediaStore;
import android.net.Uri;
import java.io.OutputStream;
import android.view.*;
import android.widget.*;
import android.content.*;
import java.text.SimpleDateFormat;
import java.util.*;

public class MainActivity extends Activity {
    final int PINK=Color.rgb(255,91,173), BG=Color.rgb(20,7,17), DARK=Color.rgb(255,235,246), PALE=Color.rgb(68,24,51), CARD=Color.rgb(39,15,32), MUTED=Color.rgb(194,157,180);
    final String[] days={"Понедельник","Вторник","Среда","Четверг","Пятница","Суббота","Воскресенье"};
    LinearLayout root, content, nav; TextView weeklyTotalView; int weekOffset=0; String page="График"; long salaryFrom=System.currentTimeMillis(), salaryTo=System.currentTimeMillis();
    Calendar monday; SharedPreferences prefs;
    public void onCreate(Bundle b){super.onCreate(b); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG); getWindow().getDecorView().setSystemUiVisibility(0); prefs=getSharedPreferences("work",0); render();}
    GradientDrawable shape(int color,int radius){GradientDrawable d=new GradientDrawable();d.setColor(color);d.setCornerRadius(radius);if(color==CARD){d.setStroke(1,Color.rgb(91,35,68));}return d;}
    TextView text(String s,int size,int color,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(size);t.setTextColor(color);if(bold)t.setTypeface(null,Typeface.BOLD);return t;}
    LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    LinearLayout horizontal(){LinearLayout l=new LinearLayout(this);l.setOrientation(0);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void pad(View v,int a){v.setPadding(a,a,a,a);}
    TextView button(String s,Runnable r){TextView t=text(s,15,PINK,true);t.setGravity(Gravity.CENTER);t.setPadding(14,12,14,12);t.setBackground(shape(CARD,28));t.setOnClickListener(v->r.run());return t;}
    String key(int day,String field){return dateKey(day)+"_"+field;}
    String dateKey(int day){Calendar c=(Calendar)monday.clone();c.add(Calendar.DAY_OF_MONTH,day);return new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(c.getTime());}
    Calendar weekStart(){Calendar c=Calendar.getInstance();c.setFirstDayOfWeek(Calendar.MONDAY);c.set(Calendar.DAY_OF_WEEK,Calendar.MONDAY);c.add(Calendar.WEEK_OF_YEAR,weekOffset);return c;}
    void render(){
        monday=weekStart(); root=vertical();root.setBackgroundColor(BG);root.setPadding(18,14,18,10);
        TextView title=text("Работа",29,DARK,true);root.addView(title);
        TextView subtitle=text(new SimpleDateFormat("d MMM",new Locale("ru")).format(monday.getTime())+" — "+weekEnd(),14,MUTED,false);subtitle.setPadding(0,2,0,12);root.addView(subtitle);
        content=vertical(); ScrollView scroll=new ScrollView(this);scroll.setFillViewport(true);scroll.addView(content,new ScrollView.LayoutParams(-1,-2));root.addView(scroll,new LinearLayout.LayoutParams(-1,0,1));
        nav=horizontal();nav.setPadding(0,8,0,0);nav.setBackground(shape(CARD,24));root.addView(nav);
        nav.addView(button(page.equals("График")?"▦  ГРАФИК":"▦  График",()->{page="График";render();}),new LinearLayout.LayoutParams(0,-2,1));
        nav.addView(button(page.equals("ЗП")?"₽  ЗАРПЛАТА":"₽  Зарплата",()->{page="ЗП";render();}),new LinearLayout.LayoutParams(0,-2,1));
        setContentView(root);
        if(page.equals("График")) showSchedule();else showSalary();
    }
    String weekEnd(){Calendar c=(Calendar)monday.clone();c.add(Calendar.DAY_OF_MONTH,6);return new SimpleDateFormat("d MMM",new Locale("ru")).format(c.getTime());}
    void showSchedule(){
        LinearLayout switcher=horizontal();switcher.setGravity(Gravity.CENTER);switcher.addView(button("‹",()->{weekOffset--;render();}));TextView w=text(weekOffset==0?"Эта неделя":weekOffset<0?Math.abs(weekOffset)+" нед. назад":weekOffset+" нед. вперёд",15,DARK,true);w.setGravity(Gravity.CENTER);switcher.addView(w,new LinearLayout.LayoutParams(0,-2,1));switcher.addView(button("›",()->{weekOffset++;render();}));content.addView(switcher);
        LinearLayout weekStrip=horizontal();weekStrip.setGravity(Gravity.CENTER);weekStrip.setPadding(0,8,0,8);
        for(int i=0;i<7;i++){ final int d=i; Calendar dc=(Calendar)monday.clone();dc.add(Calendar.DAY_OF_MONTH,i);String[] shortDays={"ПН","ВТ","СР","ЧТ","ПТ","СБ","ВС"};LinearLayout tile=vertical();tile.setGravity(Gravity.CENTER);tile.setPadding(2,8,2,8);tile.setBackground(shape(CARD,14));TextView dn=text(shortDays[i],10,MUTED,true);dn.setGravity(Gravity.CENTER);TextView num=text(new SimpleDateFormat("d",Locale.getDefault()).format(dc.getTime()),16,DARK,true);num.setGravity(Gravity.CENTER);tile.addView(dn);tile.addView(num);LinearLayout.LayoutParams tl=new LinearLayout.LayoutParams(0,-2,1);tl.setMargins(2,0,2,0);weekStrip.addView(tile,tl);}
        content.addView(weekStrip);
        TextView helper=text("Нажми на переключатель дня, чтобы выбрать смену. Время и место выбираются в отдельных окошках.",12,MUTED,false);helper.setPadding(2,2,2,8);content.addView(helper);
        for(int i=0;i<7;i++) dayCard(i);
        weeklyTotalView=text("Итого за неделю: "+money(weekTotal()),19,PINK,true);weeklyTotalView.setPadding(4,16,4,12);content.addView(weeklyTotalView);
        TextView save=button("⬇  СОХРАНИТЬ ГРАФИК В ГАЛЕРЕЮ",()->saveScheduleImage());save.setTextColor(Color.WHITE);save.setBackground(shape(PINK,24));LinearLayout.LayoutParams sp=new LinearLayout.LayoutParams(-1,-2);sp.setMargins(0,4,0,20);content.addView(save,sp);
    }
    void dayCard(int i){
        LinearLayout card=vertical();card.setPadding(14,12,14,12);card.setBackground(shape(CARD,22));LinearLayout.LayoutParams cp=new LinearLayout.LayoutParams(-1,-2);cp.setMargins(0,6,0,6);content.addView(card,cp);
        Calendar c=(Calendar)monday.clone();c.add(Calendar.DAY_OF_MONTH,i);
        LinearLayout top=horizontal();CheckBox check=new CheckBox(this);check.setButtonTintList(android.content.res.ColorStateList.valueOf(PINK));check.setText(days[i]);check.setTextColor(DARK);check.setTextSize(16);check.setTypeface(null,Typeface.BOLD);check.setChecked(prefs.getBoolean(key(i,"on"),false));top.addView(check,new LinearLayout.LayoutParams(0,-2,1));top.addView(text(new SimpleDateFormat("d.MM",Locale.getDefault()).format(c.getTime()),13,MUTED,false));card.addView(top);
        LinearLayout fields=vertical();card.addView(fields);String date=dateKey(i);
        Spinner place=timesFrom(new String[]{"Овраг","Самолет"},date+"_place",0);fieldRow(fields,"📍 Место",place);
        Spinner start=times(date+"_start","09:00"),end=times(date+"_end","17:00");
        fieldRow(fields,"◷ Начало",start);fieldRow(fields,"◷ Конец",end);
        TextView calc=text("",14,PINK,true);calc.setPadding(0,8,0,0);fields.addView(calc);
        Runnable update=()->{
            boolean on=check.isChecked();prefs.edit().putBoolean(date+"_on",on).putInt(date+"_place",place.getSelectedItemPosition()).putString(date+"_start",start.getSelectedItem().toString()).putString(date+"_end",end.getSelectedItem().toString()).apply();
            int mins=duration(start.getSelectedItem().toString(),end.getSelectedItem().toString());double hours=mins/60.0;calc.setText(on?"За день: "+fmt(hours)+" ч · "+money((long)Math.round(hours*250)):"");fields.setVisibility(on?View.VISIBLE:View.GONE);if(weeklyTotalView!=null)weeklyTotalView.setText("Итого за неделю: "+money(weekTotal()));
        };
        check.setOnCheckedChangeListener((b,v)->update.run());place.setOnItemSelectedListener(listener(update));start.setOnItemSelectedListener(listener(update));end.setOnItemSelectedListener(listener(update));
        fields.setVisibility(check.isChecked()?View.VISIBLE:View.GONE);
        int mins=duration(start.getSelectedItem().toString(),end.getSelectedItem().toString());calc.setText(check.isChecked()?"За день: "+fmt(mins/60.0)+" ч · "+money((long)Math.round(mins/60.0*250)):"");
    }
    void fieldRow(LinearLayout parent,String label,View input){LinearLayout row=horizontal();row.setPadding(0,3,0,3);TextView lab=text(label,13,MUTED,true);row.addView(lab,new LinearLayout.LayoutParams(96,-2));input.setBackground(shape(PALE,14));input.setPadding(12,0,12,0);row.addView(input,new LinearLayout.LayoutParams(0,46,1));parent.addView(row);}
    Spinner times(String k,String def){String[] vals=new String[48];for(int i=0;i<48;i++)vals[i]=String.format(Locale.US,"%02d:%02d",i/2,(i%2)*30);return timesFrom(vals,k,Arrays.asList(vals).indexOf(prefs.getString(k,def))<0?Arrays.asList(vals).indexOf(def):Arrays.asList(vals).indexOf(prefs.getString(k,def)));}
    Spinner timesFrom(String[] vals,String k,int fallback){Spinner s=new Spinner(this);ArrayAdapter<String>a=new ArrayAdapter<String>(this,android.R.layout.simple_spinner_item,vals){public View getView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getView(position,convertView,parent);t.setTextColor(DARK);t.setTextSize(14);t.setTypeface(null,Typeface.BOLD);return t;}public View getDropDownView(int position,View convertView,android.view.ViewGroup parent){TextView t=(TextView)super.getDropDownView(position,convertView,parent);t.setTextColor(DARK);t.setBackgroundColor(CARD);t.setPadding(18,16,18,16);return t;}};s.setAdapter(a);int sel=prefs.getInt(k,fallback);s.setSelection(Math.max(0,Math.min(sel,vals.length-1)));return s;}
    android.widget.AdapterView.OnItemSelectedListener listener(Runnable r){return new android.widget.AdapterView.OnItemSelectedListener(){public void onItemSelected(android.widget.AdapterView<?> p,View v,int pos,long id){r.run();}public void onNothingSelected(android.widget.AdapterView<?> p){}};}
    int duration(String a,String b){String[] x=a.split(":"),y=b.split(":");int s=Integer.parseInt(x[0])*60+Integer.parseInt(x[1]),e=Integer.parseInt(y[0])*60+Integer.parseInt(y[1]);return Math.max(0,e-s);}
    String fmt(double x){return x==(long)x?""+(long)x:String.format(Locale.US,"%.1f",x);}
    String money(long x){return x+" ₽";}
    long weekTotal(){long total=0;for(int i=0;i<7;i++)if(prefs.getBoolean(key(i,"on"),false)){String a=prefs.getString(key(i,"start"),"09:00"),b=prefs.getString(key(i,"end"),"17:00");total+=Math.round(duration(a,b)/60.0*250);}return total;}
    void showSalary(){
        TextView heading=text("Расчёт зарплаты",25,DARK,true);heading.setPadding(2,12,0,6);content.addView(heading);
        TextView sub=text("Выбери период — посчитаю смены и часы за эти даты.",13,MUTED,false);sub.setPadding(2,0,0,16);content.addView(sub);
        LinearLayout card=vertical();card.setPadding(18,18,18,18);card.setBackground(shape(CARD,24));content.addView(card);
        Calendar now=Calendar.getInstance();if(salaryFrom==0)salaryFrom=now.getTimeInMillis();if(salaryTo==0)salaryTo=now.getTimeInMillis();
        TextView from=text("С ДАТЫ",11,MUTED,true);card.addView(from);TextView fromBtn=button(dateLabel(salaryFrom)+"  ▾",()->pickDate(true));fromBtn.setTextColor(DARK);card.addView(fromBtn);
        TextView to=text("ПО ДАТУ",11,MUTED,true);to.setPadding(0,14,0,0);card.addView(to);TextView toBtn=button(dateLabel(salaryTo)+"  ▾",()->pickDate(false));toBtn.setTextColor(DARK);card.addView(toBtn);
        TextView result=text("",28,PINK,true);result.setPadding(0,22,0,0);card.addView(result);
        TextView hours=text("",15,DARK,false);hours.setPadding(0,8,0,0);card.addView(hours);
        Runnable calc=()->{long totalMins=0;int shifts=0;Calendar c=Calendar.getInstance();c.setTimeInMillis(salaryFrom);Calendar finish=Calendar.getInstance();finish.setTimeInMillis(salaryTo);c.set(Calendar.HOUR_OF_DAY,0);c.set(Calendar.MINUTE,0);finish.set(Calendar.HOUR_OF_DAY,0);finish.set(Calendar.MINUTE,0);while(!c.after(finish)){String dk=new SimpleDateFormat("yyyy-MM-dd",Locale.getDefault()).format(c.getTime());if(prefs.getBoolean(dk+"_on",false)){String a=prefs.getString(dk+"_start","09:00"),b=prefs.getString(dk+"_end","17:00");totalMins+=duration(a,b);shifts++;}c.add(Calendar.DAY_OF_MONTH,1);}result.setText(money(Math.round(totalMins/60.0*250)));hours.setText("Смен: "+shifts+"  ·  Часов: "+fmt(totalMins/60.0)+"  ·  Ставка: 250 ₽/ч");};
        fromBtn.setOnClickListener(v->{pickDate(true);});toBtn.setOnClickListener(v->{pickDate(false);});
        TextView note=text("Учитываются только отмеченные смены внутри выбранного периода. Чтобы заполнить другие даты, перейди во вкладку «График» и переключи неделю.",12,MUTED,false);note.setPadding(2,16,2,0);content.addView(note);calc.run();
    }
    String dateLabel(long millis){return new SimpleDateFormat("d MMMM yyyy",new Locale("ru")).format(new Date(millis));}
    void pickDate(boolean from){Calendar c=Calendar.getInstance();c.setTimeInMillis(from?salaryFrom:salaryTo);new DatePickerDialog(this,(view,y,m,d)->{Calendar chosen=Calendar.getInstance();chosen.set(y,m,d,12,0,0);if(from){salaryFrom=chosen.getTimeInMillis();if(salaryFrom>salaryTo)salaryTo=salaryFrom;}else{salaryTo=chosen.getTimeInMillis();if(salaryTo<salaryFrom)salaryFrom=salaryTo;}render();},c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show();}
    void saveScheduleImage(){
        try{
            int width=1080, rowH=150, height=330+rowH*7;Bitmap bmp=Bitmap.createBitmap(width,height,Bitmap.Config.ARGB_8888);Canvas canvas=new Canvas(bmp);canvas.drawColor(BG);Paint p=new Paint(3);p.setColor(PINK);canvas.drawRoundRect(new RectF(40,40,width-40,220),42,42,p);p.setColor(Color.WHITE);p.setTextSize(54);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));canvas.drawText("МОЙ ГРАФИК СМЕН",80,120,p);p.setTextSize(32);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));canvas.drawText(new SimpleDateFormat("d MMM",new Locale("ru")).format(monday.getTime())+" — "+weekEnd(),80,175,p);
            int y=260;String[] shortDays={"ПОНЕДЕЛЬНИК","ВТОРНИК","СРЕДА","ЧЕТВЕРГ","ПЯТНИЦА","СУББОТА","ВОСКРЕСЕНЬЕ"};for(int i=0;i<7;i++){String dk=dateKey(i);boolean on=prefs.getBoolean(dk+"_on",false);p.setColor(CARD);canvas.drawRoundRect(new RectF(40,y,width-40,y+rowH-14),28,28,p);p.setColor(on?DARK:MUTED);p.setTextSize(30);p.setTypeface(Typeface.create("sans-serif",Typeface.BOLD));canvas.drawText(shortDays[i],75,y+48,p);p.setTextSize(27);p.setTypeface(Typeface.create("sans-serif",Typeface.NORMAL));String info=on?prefs.getString(dk+"_start","09:00")+" — "+prefs.getString(dk+"_end","17:00")+"   ·   "+new String[]{"Овраг","Самолет"}[prefs.getInt(dk+"_place",0)]:"Выходной";canvas.drawText(info,75,y+98,p);y+=rowH;}
            String name="Rabota_Grafik_"+System.currentTimeMillis()+".png";android.content.ContentValues values=new android.content.ContentValues();values.put(MediaStore.Images.Media.DISPLAY_NAME,name);values.put(MediaStore.Images.Media.MIME_TYPE,"image/png");if(android.os.Build.VERSION.SDK_INT>=29)values.put(MediaStore.Images.Media.RELATIVE_PATH,"Pictures/Работа");Uri uri=getContentResolver().insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI,values);if(uri==null)throw new Exception("Не удалось создать файл");OutputStream out=getContentResolver().openOutputStream(uri);bmp.compress(Bitmap.CompressFormat.PNG,100,out);out.close();bmp.recycle();Toast.makeText(this,"График сохранён в галерею",Toast.LENGTH_LONG).show();Intent share=new Intent(Intent.ACTION_SEND);share.setType("image/png");share.putExtra(Intent.EXTRA_STREAM,uri);share.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);startActivity(Intent.createChooser(share,"Отправить график"));
        }catch(Exception e){Toast.makeText(this,"Не удалось сохранить график: "+e.getMessage(),Toast.LENGTH_LONG).show();}
    }

}
